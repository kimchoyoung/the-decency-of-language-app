package com.beens;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LogIn extends Activity {
    public static final int SIGNIN_REQUEST_CODE = 99;
    public static final int LOGIN_RESULT_CODE = 10;
    public static final int GUEST_LOGIN_RESULT_CODE = 11;
    private Intent resultIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_setting);
        Button login_btn = findViewById(R.id.login_btn);
        Button signin_btn = findViewById(R.id.signin_btn);
        Button guest_btn = findViewById(R.id.guest_btn);
        resultIntent = getIntent();

        /** set action when user long in **/
        login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user_email = ((EditText)findViewById(R.id.emailInput)).getText().toString();
                String user_pwd = ((EditText)findViewById(R.id.passwordInput)).getText().toString();
                resultIntent.putExtra("user_email", user_email);
                resultIntent.putExtra("user_pwd", user_pwd);
                setResult(RESULT_OK, resultIntent);
                // Send data to server for checking identification
//                if(Server.login_process(getBaseContext(), user_email, user_pwd)==true)
                    finish();
//                Toast.makeText(getBaseContext(),"이메일 혹은 비밀번호가 일치하지 않습니다.",Toast.LENGTH_LONG).show();
            }
        });
        /** set action when user sign in **/
        signin_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent signinIntent = new Intent(LogIn.this, SignIn.class);
                startActivityForResult(signinIntent,SIGNIN_REQUEST_CODE);
            }
        });
        /** set action when user is a guest **/
        guest_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(LogIn.this );
                builder.setTitle("GUEST 로그인");
                builder.setMessage("GUEST모드 사용시 일부 기능 사용에 제한이 있습니다.");
                builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(LogIn.this,"GUEST로그인 상태입니다.",Toast.LENGTH_SHORT).show();
                        resultIntent.putExtra("user_email","GUEST");
                        resultIntent.putExtra("user_pwd","");
                        setResult(GUEST_LOGIN_RESULT_CODE,resultIntent);
                        finish();
                    }
                });
                builder.setNegativeButton("취소", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {}
                });
                builder.show();
            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        if(resultCode == RESULT_OK) {
            if (requestCode == SIGNIN_REQUEST_CODE) {
                String new_email = intent.getStringExtra("new_email");
                String new_pwd = intent.getStringExtra("new_pwd");
                ((EditText)findViewById(R.id.emailInput)).setText(new_email);
                ((EditText)findViewById(R.id.passwordInput)).setText(new_pwd);
                resultIntent.putExtra("setting_state", false);
            }
        }
    }
}
