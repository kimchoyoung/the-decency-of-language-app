package com.beens;

import android.app.DownloadManager;
import android.content.Context;
import android.icu.text.SimpleDateFormat;
import android.os.Environment;
import android.util.Log;
import android.view.View;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Server {
    private static final String BASE_PATH = Environment.getExternalStorageDirectory() + "/myapp";
    private static final String NORMAL_PATH = BASE_PATH + "/normal";
    private String each_response = "";

    private String url="http://172.20.10.11:3000/";

    public boolean login_process(final Context context, String user_email, String user_pwd) {
        String query = "login?id="+user_email+"&password="+user_pwd;
        if(send_toServer(context, query).equals("True")==true)
            return true;
        return false;
    }
    public boolean signin_process(final Context context, String user_name, String user_email, String user_pwd) {
        String query = "&user_name="+user_name+"&user_email="+user_email+"&user_pwd="+user_pwd;
        // TODO: Fill the method of sign-in process
        // ...
        return false;
    }
    public String send_toServer(final Context context, String query){
        long now = System.currentTimeMillis();
        Date date = new Date(now);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd, hh:mm");
        String getTime = sdf.format(date);

        StringRequest request = new StringRequest(Request.Method.GET, url+ query+"&time="+getTime ,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            each_response = response;
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                    }
                }
        ){
            @Override
            protected Map<String, String> getParams(){
                Map<String, String> params = new HashMap<>();
                params.put("time","11111");
                return params;
            }
        };
        request.setShouldCache(false);
        Volley.newRequestQueue(context).add(request);
        return each_response;
    }
}
