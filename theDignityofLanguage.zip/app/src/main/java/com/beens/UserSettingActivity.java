package com.beens;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UserSettingActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_setting);
        Button login_btn = findViewById(R.id.login_btn);
        Button signin_btn = findViewById(R.id.signin_btn);
        Button guest_btn = findViewById(R.id.guest_btn);

        /** set action when user long in **/
        login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user_email = ((EditText)findViewById(R.id.emailInput)).getText().toString();
                String user_pwd = ((EditText)findViewById(R.id.passwordInput)).getText().toString();
                Intent resultIntent = getIntent();
                setResult(RESULT_OK, resultIntent);
                Server server = new Server();
                if(server.login_process(getBaseContext(), user_email, user_pwd)==true)
                    finish();
                Toast.makeText(getBaseContext(),"이메일 혹은 비밀번호가 일치하지 않습니다.",Toast.LENGTH_LONG).show();
            }
        });
        /** set action when user sign in **/
        signin_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        /** set action when user is a guest **/
        guest_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }
}
