package com.beens;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SignIn extends AppCompatActivity {
    private String new_name;
    private String new_email;
    private String new_pwd;
    private String new_pwdcheck;
    private Button new_signin_btn;
    private Button IDcheck_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_preference);

        new_signin_btn = (Button) findViewById(R.id.new_signin_btn);
        IDcheck_btn = (Button) findViewById(R.id.ID_check_btn);

        new_signin_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new_email = ((EditText) findViewById(R.id.new_email)).getText().toString();
                new_pwd = ((EditText) findViewById(R.id.new_pwd)).getText().toString();
                new_pwdcheck = ((EditText) findViewById(R.id.new_pwdcheck)).getText().toString();
                new_name = ((EditText) findViewById(R.id.new_name)).getText().toString();
                // if ( bool ID 중복확인 is true ) 추가..
                if(new_email.equals("") || new_pwd.equals("") || new_pwdcheck.equals("") || new_name.equals("")) {
                    Toast.makeText(SignIn.this, "입력정보가 부족합니다.", Toast.LENGTH_SHORT).show();
                }
                else if (!new_pwd.equals(new_pwdcheck)) {
                    Toast.makeText(SignIn.this,"비밀번호를 확인하세요.",Toast.LENGTH_SHORT).show();
                }
                else {
                    Intent return_intent = new Intent();
                    return_intent.putExtra("name",new_name);
                    return_intent.putExtra("new_email", new_email);
                    return_intent.putExtra("new_pwd", new_pwd);
                    setResult(RESULT_OK, return_intent);
                    /**  send new data to server for registration **/
                    Server.signin_process(getBaseContext(),new_name, new_email, new_pwd);
                    finish();
                }
            }
        });
        IDcheck_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Server.id_check(getBaseContext(), new_email);
            }
        });
    }
}
