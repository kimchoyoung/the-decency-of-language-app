package com.beens;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.speech.RecognitionListener;
import android.speech.SpeechRecognizer;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;

public class TestService extends Service {
    ArrayList<String> txt = new ArrayList<>();
    final SpeechRecognizer stt = SpeechRecognizer.createSpeechRecognizer(this);
    public TestService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public void onDestroy() {
        stt.stopListening();
        stt.destroy();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Toast.makeText(this, "음성인식을 시작합니다.", Toast.LENGTH_SHORT).show();
        inputVoice(txt,intent);
        return START_NOT_STICKY;
    }

    public void inputVoice(final ArrayList<String> txt, final Intent intent) {

        try {
            stt.setRecognitionListener(new RecognitionListener() {
                @Override
                public void onReadyForSpeech(Bundle bundle) {
                    toast("음성 입력 준비완료!");
                }

                @Override
                public void onBeginningOfSpeech() {
                }

                @Override
                public void onRmsChanged(float v) {
                }

                @Override
                public void onBufferReceived(byte[] bytes) {
                    showLog("check");
                }

                @Override
                public void onEndOfSpeech() {
                    toast("음성 입력 종료!");
                }

                @Override
                public void onError(int error) {
//                    toast("오류 발생 : " + error);
                    stt.destroy();
                    inputVoice(txt,intent);
                }

                @Override
                public void onResults(Bundle results) {
                    ArrayList<String> result = (ArrayList<String>)results.get(SpeechRecognizer.RESULTS_RECOGNITION);
                    txt.add("[나] "+result.get(0)+"\n");
                    showLog(result.get(0));
                    replyAnswer(result.get(0), txt);

                    stt.stopListening();
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        public void run() {
                            // yourMethod();
                        }
                    }, 5000);   //5 seconds
                    stt.startListening(intent);
                }

                @Override
                public void onPartialResults(Bundle bundle) {
                    showLog("partial result");
                }

                @Override
                public void onEvent(int i, Bundle bundle) {
                    toast("이벤트");
                }
            });
            stt.startListening(intent);

        }catch (Exception e) {
            toast(e.toString());
        }
    }
    public void showLog(String log) {
        Log.d("[myLOG]", log);
    }
    public void toast(String msg){
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }
    private void replyAnswer(String input, ArrayList<String> txt) {
        try {
            if(input.contains("강아지")) {
                //txt.add("[어플] 멍멍멍~!!\n");
                toast("멍멍멍");
            }else if(input.contains("고양이")) {
                //txt.add("[어플] 야아아아아아옹~!!\n");
                toast("야오오옹");
            }else {
                //txt.add("[어플] 뭐라는 거야....\n");
                toast("룰루랄라");
            }
        }catch (Exception e) {
            toast(e.toString());
        }
    }
}
