package com.beens;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    private SharedPreferences  myPreferences;
    private SharedPreferences.Editor editor;
    public static final int REQUEST_CODE_SETTING = 1000;
    private int requestCode = 0;
    private int resultCode = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        myPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        editor = myPreferences.edit();
        editor.putString("user_email", null);

//        if(!myPreferences.getBoolean("setting",false) || myPreferences.getString("user_email", null)==null) {
            Intent intent = new Intent(getApplicationContext(), UserSettingActivity.class);
            startActivityForResult(intent,REQUEST_CODE_SETTING);
//        }
        setContentView(R.layout.activity_main);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        this.requestCode = requestCode;
        this.resultCode = resultCode;
        /** Result of Setting **/
        if(requestCode == REQUEST_CODE_SETTING) {
            Toast.makeText(getBaseContext(),"User setting is done",Toast.LENGTH_LONG).show();
            editor.putBoolean("setting", true);
            editor.commit();
            String userinfo = intent.getStringExtra("user_email").toString()+"\n"+intent.getStringExtra("user_pwd").toString();
            ((TextView)findViewById(R.id.user_info)).setText(userinfo);
        }
    }
}
