package com.beens;

import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.speech.RecognizerIntent;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class SetTime extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_time);
        final Intent start_intent = new Intent("com.beens.test.ALARM_START");
        start_intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, this.getPackageName());
        start_intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ko-KR");

        final Intent end_intent = new Intent("com.beens.test.ALARM_STOP");
        end_intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, this.getPackageName());
        end_intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ko-KR");

        Calendar Start_Calendar = Calendar.getInstance();
        Start_Calendar.set(Calendar.HOUR_OF_DAY,13);
        Start_Calendar.set(Calendar.MINUTE,47);
        Start_Calendar.set(Calendar.SECOND,00);

        Calendar End_Calendar = Calendar.getInstance();
        End_Calendar.set(Calendar.HOUR_OF_DAY,13);
        End_Calendar.set(Calendar.MINUTE,50);
        End_Calendar.set(Calendar.SECOND,00);

        final PendingIntent startPendingIntent =
                PendingIntent.getBroadcast (
                        this,
                        0,
                        start_intent,
                        PendingIntent.FLAG_CANCEL_CURRENT
                );

        final PendingIntent endPendingIntent =
                PendingIntent.getBroadcast (
                        this,
                        0,
                        end_intent,
                        PendingIntent.FLAG_CANCEL_CURRENT
                );

        final AlarmManager startAlarmManager = (AlarmManager)getSystemService(Context.ALARM_SERVICE);
        startAlarmManager.set(
                AlarmManager.RTC_WAKEUP,
                Start_Calendar.getTimeInMillis(),
                startPendingIntent
        );

        final AlarmManager endAlarmManager = (AlarmManager)getSystemService(Context.ALARM_SERVICE);
        endAlarmManager.set(
                AlarmManager.RTC_WAKEUP,
                End_Calendar.getTimeInMillis(),
                endPendingIntent
        );

        final TextView txt = findViewById(R.id.content);
        Button button = findViewById(R.id.recordBtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                mAlarmManager.cancel(mPendingIntent);
            }
        });
    }
}
