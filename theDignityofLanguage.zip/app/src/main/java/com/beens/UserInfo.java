package com.beens;

public class UserInfo {
    private String user_name;
    private String user_email;
    private String user_pwd;
    public UserInfo() {
        this.user_email = null;
        this.user_pwd = null;
    }
    public UserInfo(String email, String pwd) {
        this.user_email = email;
        this.user_pwd = pwd;
    }
    public boolean checkPassword(String user_pwd) {
        return this.user_pwd == user_pwd;
    }
    public void changePassword(String new_pwd) {
        user_pwd = new_pwd;
    }
}
